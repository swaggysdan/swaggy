﻿Name: Yixiong Qin
Date : 10/05/2018

Initial thought: I was thinking that PS2 and PS3 would be my starting point since I need formula
class from PS 2 for arithmetic operation and PS3 for building relationships between cells.

Versions: I will be using Formula.dll and SpreadsheetUtilities.dll from PS2 and PS3.

I also planed to use some helper methods in order to reduce the redundent codes.